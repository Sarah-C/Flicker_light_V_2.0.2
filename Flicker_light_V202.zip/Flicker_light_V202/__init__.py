import bpy
import random
from bpy.props import FloatProperty, IntProperty, PointerProperty, EnumProperty
from bpy.types import PropertyGroup, Panel, Operator
from bpy.app.translations import pgettext_iface as _

TRANSLATIONS = {
    'en': {
        'tab': "Flicker",
        'panel_title': "Flickering Light",
        'language': "Language",
        'duration': "Duration (frames)",
        'seed': "Random Seed",
        'frequency': "Update Frequency",
        'mode': "Power Mode",
        'mode_percent': "Percent of Base",
        'mode_absolute': "Absolute Range",
        'min_factor': "Min Factor (%)",
        'max_factor': "Max Factor (%)",
        'min_power': "Min Power",
        'max_power': "Max Power",
        'desc_percent_1': "The light power will oscillate between base × min% and base × max%.",
        'desc_percent_2': "Example: base=1000, min=50%, max=150% → 500–1500.",
        'desc_absolute_1': "The light power will oscillate between the absolute min and max values.",
        'desc_absolute_2': "Example: min=1000, max=1100 → 1000–1100.",
        'run': "Simulate Flickering",
        'guide': (
            "Select one or more lights, set parameters, then click 'Simulate Flickering' to add a flicker animation.\n"
            "Duration: how many frames the effect lasts.\n"
            "Update Frequency: frames between keyframes.\n"
            "Random Seed: change for different noise patterns.\n"
            "Power Mode:\n"
            " - Percent of Base: range is base × [min%, max%].\n"
            " - Absolute Range: range is [min power, max power]."
        ),
        'err_no_lights': "No lights selected",
    },
    'it': {
        'tab': "Scintilla",
        'panel_title': "Illuminazione Scintillante",
        'language': "Lingua",
        'duration': "Durata (frame)",
        'seed': "Seed Casuale",
        'frequency': "Frequenza Aggiornamento",
        'mode': "Modalità Potenza",
        'mode_percent': "Percentuale sulla base",
        'mode_absolute': "Intervallo assoluto",
        'min_factor': "Fattore minimo (%)",
        'max_factor': "Fattore massimo (%)",
        'min_power': "Potenza minima",
        'max_power': "Potenza massima",
        'desc_percent_1': "La potenza oscillerà tra base × min% e base × max%.",
        'desc_percent_2': "Esempio: base=1000, min=50%, max=150% → 500–1500.",
        'desc_absolute_1': "La potenza oscillerà tra i valori assoluti min e max.",
        'desc_absolute_2': "Esempio: min=1000, max=1100 → 1000–1100.",
        'run': "Simula Scintillio",
        'guide': (
            "Seleziona una o più luci, imposta i parametri e clicca 'Simula Scintillio' per aggiungere l'animazione.\n"
            "Durata: numero di frame dell'effetto.\n"
            "Frequenza Aggiornamento: frame tra i keyframe.\n"
            "Seed Casuale: cambia per pattern diversi.\n"
            "Modalità Potenza:\n"
            " - Percentuale: range = base × [min%, max%].\n"
            " - Assoluta: range = [potenza min, potenza max]."
        ),
        'err_no_lights': "Nessuna luce selezionata",
    },
    'fr': {
        'tab': "Clignotement",
        'panel_title': "Lumière Clignotante",
        'language': "Langue",
        'duration': "Durée (frames)",
        'seed': "Graine Aléatoire",
        'frequency': "Fréquence Màj",
        'mode': "Mode de Puissance",
        'mode_percent': "Pourcentage de base",
        'mode_absolute': "Plage absolue",
        'min_factor': "Facteur min (%)",
        'max_factor': "Facteur max (%)",
        'min_power': "Puissance min",
        'max_power': "Puissance max",
        'desc_percent_1': "La puissance oscillera entre base × min% et base × max%.",
        'desc_percent_2': "Exemple : base=1000, min=50%, max=150% → 500–1500.",
        'desc_absolute_1': "La puissance oscillera entre des valeurs absolues min et max.",
        'desc_absolute_2': "Exemple : min=1000, max=1100 → 1000–1100.",
        'run': "Simuler Clignotement",
        'guide': (
            "Sélectionnez une ou plusieurs lumières, réglez les paramètres puis cliquez 'Simuler Clignotement'.\n"
            "Durée : nombre de frames de l'effet.\n"
            "Fréquence Màj : frames entre les keyframes.\n"
            "Graine Aléatoire : modifiez pour des motifs différents.\n"
            "Mode de Puissance :\n"
            " - Pourcentage : plage = base × [min%, max%].\n"
            " - Absolu : plage = [puissance min, puissance max]."
        ),
        'err_no_lights': "Aucune lumière sélectionnée",
    },
    'de': {
        'tab': "Flackern",
        'panel_title': "Flackerndes Licht",
        'language': "Sprache",
        'duration': "Dauer (Frames)",
        'seed': "Zufalls-Seed",
        'frequency': "Aktualisierungsfreq.",
        'mode': "Leistungsmodus",
        'mode_percent': "Prozent der Basis",
        'mode_absolute': "Absoluter Bereich",
        'min_factor': "Mindestfaktor (%)",
        'max_factor': "Maximalfaktor (%)",
        'min_power': "Mindestleistung",
        'max_power': "Maximalleistung",
        'desc_percent_1': "Die Leistung oszilliert zwischen Basis × Min% und Basis × Max%.",
        'desc_percent_2': "Beispiel: Basis=1000, Min=50%, Max=150% → 500–1500.",
        'desc_absolute_1': "Die Leistung oszilliert zwischen absoluten Min- und Max-Werten.",
        'desc_absolute_2': "Beispiel: Min=1000, Max=1100 → 1000–1100.",
        'run': "Flackern Simulieren",
        'guide': (
            "Wählen Sie ein oder mehrere Lichter, setzen Sie Parameter und klicken Sie auf 'Flackern Simulieren'.\n"
            "Dauer: Anzahl der Frames.\n"
            "Aktualisierungsfreq.: Frames zwischen Keyframes.\n"
            "Zufalls-Seed: anderes Rauschmuster.\n"
            "Leistungsmodus:\n"
            " - Prozent: Bereich = Basis × [Min%, Max%].\n"
            " - Absolut: Bereich = [Min-Leistung, Max-Leistung]."
        ),
        'err_no_lights': "Keine Lichter ausgewählt",
    },
    'es': {
        'tab': "Parpadeo",
        'panel_title': "Luz Parpadeante",
        'language': "Idioma",
        'duration': "Duración (frames)",
        'seed': "Seed Aleatorio",
        'frequency': "Frecuencia",
        'mode': "Modo de Potencia",
        'mode_percent': "Porcentaje de la base",
        'mode_absolute': "Rango absoluto",
        'min_factor': "Factor mínimo (%)",
        'max_factor': "Factor máximo (%)",
        'min_power': "Potencia mínima",
        'max_power': "Potencia máxima",
        'desc_percent_1': "La potencia oscilará entre base × mín% y base × máx%.",
        'desc_percent_2': "Ejemplo: base=1000, mín=50%, máx=150% → 500–1500.",
        'desc_absolute_1': "La potencia oscilará entre valores absolutos mínimo y máximo.",
        'desc_absolute_2': "Ejemplo: mín=1000, máx=1100 → 1000–1100.",
        'run': "Simular Parpadeo",
        'guide': (
            "Selecciona una o más luces, ajusta parámetros y pulsa 'Simular Parpadeo'.\n"
            "Duración: número de frames del efecto.\n"
            "Frecuencia: frames entre keyframes.\n"
            "Seed Aleatorio: cambia el patrón de ruido.\n"
            "Modo de Potencia:\n"
            " - Porcentaje: rango = base × [mín%, máx%].\n"
            " - Absoluto: rango = [potencia mín, potencia máx]."
        ),
        'err_no_lights': "No hay luces seleccionadas",
    }
}

def _resolve_lang(context, settings):
    lang = settings.language
    if lang == 'AUTO':
        ui = context.preferences.view.language
        code = (ui[:2].lower() if ui else 'en')
        return code if code in TRANSLATIONS else 'en'
    return settings.language.lower()

class FlickerSettings(PropertyGroup):
    language: EnumProperty(
        name=_("Language"),
        items=[
            ('AUTO', "Auto", "Use Blender UI language"),
            ('EN', "English", ""),
            ('IT', "Italiano", ""),
            ('FR', "Français", ""),
            ('DE', "Deutsch", ""),
            ('ES', "Español", ""),
        ],
        default='AUTO'
    )
    duration: IntProperty(name="", default=250, min=1)
    seed: IntProperty(name="", default=0, min=0)
    frequency: IntProperty(name="", default=1, min=1)

    mode: EnumProperty(
        name="",
        items=[('PERCENT', "PERCENT", ""), ('ABSOLUTE', "ABSOLUTE", "")],
        default='PERCENT'
    )
    min_factor: FloatProperty(name="", default=50.0, min=0.0, subtype='PERCENTAGE')
    max_factor: FloatProperty(name="", default=150.0, min=0.0, subtype='PERCENTAGE')
    min_power: FloatProperty(name="", default=1000.0, min=0.0)
    max_power: FloatProperty(name="", default=1100.0, min=0.0)

class OBJECT_OT_simulate_flicker(Operator):
    bl_idname = "object.simulate_flicker"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.flicker_settings
        selected = [obj for obj in context.selected_objects if obj.type == 'LIGHT']
        if not selected:
            self.report({'WARNING'}, _("No lights selected"))
            return {'CANCELLED'}

        random.seed(settings.seed)
        start = context.scene.frame_current
        end = start + settings.duration
        step = max(1, settings.frequency)

        for light in selected:
            data = light.data
            base = float(data.energy)

            if settings.mode == 'PERCENT':
                lo = base * (settings.min_factor / 100.0)
                hi = base * (settings.max_factor / 100.0)
            else:
                lo = settings.min_power
                hi = settings.max_power

            if hi < lo:
                lo, hi = hi, lo

            for f in range(start, end, step):
                val = random.uniform(lo, hi)
                data.energy = max(0.0, val)
                data.keyframe_insert(data_path="energy", frame=f)

        return {'FINISHED'}

class OBJECT_PT_flicker_panel(Panel):
    bl_idname = "OBJECT_PT_flicker_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Flicker"       # must stay static
    bl_label = "Flickering Light" # must stay static

    def draw(self, context):
        settings = context.scene.flicker_settings
        lang = _resolve_lang(context, settings)
        tr = TRANSLATIONS.get(lang, TRANSLATIONS['en'])

        layout = self.layout
        row = layout.row()
        row.prop(settings, 'language', text=tr['language'])

        layout.label(text=tr['mode'])
        row = layout.row()
        row.prop(settings, 'mode', text="")
        if settings.mode == 'PERCENT':
            layout.label(text=tr['desc_percent_1'])
            layout.label(text=tr['desc_percent_2'])
        else:
            layout.label(text=tr['desc_absolute_1'])
            layout.label(text=tr['desc_absolute_2'])

        if settings.mode == 'PERCENT':
            layout.prop(settings, 'min_factor', text=tr['min_factor'])
            layout.prop(settings, 'max_factor', text=tr['max_factor'])
        else:
            layout.prop(settings, 'min_power', text=tr['min_power'])
            layout.prop(settings, 'max_power', text=tr['max_power'])

        layout.prop(settings, 'duration', text=tr['duration'])
        layout.prop(settings, 'frequency', text=tr['frequency'])
        layout.prop(settings, 'seed', text=tr['seed'])

        layout.operator('object.simulate_flicker', text=tr['run'])

        for line in tr['guide'].split('\n'):
            layout.label(text=line)

def register():
    bpy.utils.register_class(FlickerSettings)
    bpy.utils.register_class(OBJECT_OT_simulate_flicker)
    bpy.utils.register_class(OBJECT_PT_flicker_panel)
    bpy.types.Scene.flicker_settings = PointerProperty(type=FlickerSettings)

def unregister():
    bpy.utils.unregister_class(FlickerSettings)
    bpy.utils.unregister_class(OBJECT_OT_simulate_flicker)
    bpy.utils.unregister_class(OBJECT_PT_flicker_panel)
    del bpy.types.Scene.flicker_settings

if __name__ == '__main__':
    register()
